main(){
	int n = 2;
	unsigned int num = 12345,pos; 
	char cadena[] = "Hola micro", subcadena[] = "micr", subcadena2[]="Hola BEBA CAFE";
	char numeroDeCuenta1[] = "0438853602", numeroDeCuenta2[] = "1000000000";
	printf("----------Ejercicio 3a--------------\n");
	printf("Prueba impar positivo, para salir introduzca 0\n");
	do{
		printf("Introduzca un numero\n");
		scanf("%d",&n);
		printf(">>%d\n",imparPositivo(n));
	}while(n != 0);
	
	printf("Prueba Calcula Digito\n");
	for(pos = 1; pos <= 5 ; pos ++){
        printf("%d\n",calculaDigito(num,pos));
    }
	printf("Prueba siguiente primo, para salir introduzca 1\n");
	do{
		printf("Introduzca un numero\n");
		scanf("%u",&num);
		printf(">>%u\n",siguientePrimo(num));
	}while(num != 1);
	printf("----------Ejercicio 3b--------------\n");
	printf("Prueba encuentra subcadena\n");
	printf(">>%d\n",encuentraSubcadena (cadena, subcadena));
	printf(">>%d\n",encuentraSubcadena (cadena, subcadena2));
	printf("Prueba calcula segundo DC\n");
	printf("Cuenta a comprobar : %s\n",numeroDeCuenta1 );
	printf(">>%u\n",calculaSegundoDC(numeroDeCuenta1));
	printf("Cuenta a comprobar : %s\n",numeroDeCuenta2);
	printf(">>%u\n",calculaSegundoDC(numeroDeCuenta2));
}